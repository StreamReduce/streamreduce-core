package com.streamreduce.core.metric;

/**
 * Enumeration to describe the possible metrics types to send to the Juggaloader.
 */
public enum MetricModeType {
    DELTA,
    ABSOLUTE
}
