package com.streamreduce.core.metric;

/**
 * <p>Author: Nick Heudecker</p>
 * <p>Created: 8/27/12 14:19</p>
 */
public enum MetricValueType {

    FLOAT,
    ENUM,
    FLOAT_GEO

}
