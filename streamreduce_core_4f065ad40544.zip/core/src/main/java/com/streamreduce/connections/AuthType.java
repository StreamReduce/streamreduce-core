package com.streamreduce.connections;

public enum AuthType {
    OAUTH,
    USERNAME_PASSWORD,
    NONE,
    API_KEY,
    USERNAME_PASSWORD_WITH_API_KEY
}
