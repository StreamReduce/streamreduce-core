package com.streamreduce.connections;

import com.streamreduce.ConnectionTypeConstants;

public interface FeedProvider extends ConnectionProvider {
    public static final String TYPE = ConnectionTypeConstants.FEED_TYPE;
}
