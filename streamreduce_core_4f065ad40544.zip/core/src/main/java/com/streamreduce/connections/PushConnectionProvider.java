package com.streamreduce.connections;

/**
 * <p>Author: Nick Heudecker</p>
 * <p>Created: 8/14/12 10:12</p>
 */
public interface PushConnectionProvider extends ConnectionProvider {

}
