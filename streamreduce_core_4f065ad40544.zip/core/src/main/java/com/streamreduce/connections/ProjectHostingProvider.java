package com.streamreduce.connections;

import com.streamreduce.ConnectionTypeConstants;

public interface ProjectHostingProvider extends ConnectionProvider {

    public static final String TYPE = ConnectionTypeConstants.PROJECT_HOSTING_TYPE;

}
