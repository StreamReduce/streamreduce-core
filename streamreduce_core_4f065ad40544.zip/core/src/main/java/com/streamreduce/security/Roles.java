package com.streamreduce.security;

/*
 * Preloaded Nodeable generated Roles.
 */
public class Roles {

    public static final String ADMIN_ROLE = "Administrators";
    public static final String DEVELOPER_ROLE = "Developers";
    public static final String USER_ROLE = "Users";

}
