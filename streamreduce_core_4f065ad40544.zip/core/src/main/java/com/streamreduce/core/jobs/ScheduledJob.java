package com.streamreduce.core.jobs;

public interface ScheduledJob {
    void doJob();
}
