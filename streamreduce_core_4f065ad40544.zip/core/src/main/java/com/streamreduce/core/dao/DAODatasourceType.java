package com.streamreduce.core.dao;

public enum DAODatasourceType {
    BUSINESS,
    MESSAGE
}
