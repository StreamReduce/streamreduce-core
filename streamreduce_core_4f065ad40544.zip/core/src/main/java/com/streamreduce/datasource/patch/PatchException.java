package com.streamreduce.datasource.patch;

import com.streamreduce.NodeableException;

public class PatchException extends NodeableException{

    private static final long serialVersionUID = 5748556467805060115L;

    protected PatchException(String s) {
        super(s);
    }
}
